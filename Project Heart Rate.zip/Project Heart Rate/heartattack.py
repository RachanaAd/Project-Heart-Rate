import streamlit as st
import pandas as pd
import joblib
import base64

# Load the saved model for heart attack prediction
model_path = 'C:/Users/Sugam Sharma/Desktop/Project Heart Rate/ML_MODEL/random_forest_model.pkl'
model = joblib.load(model_path)

# Define the expected columns for heart attack prediction
expected_columns = [
    'age', 'sex', 'cp', 'trtbps', 'chol', 'fbs', 'restecg', 'thalachh',
    'exng', 'oldpeak', 'slp', 'caa', 'thall', 'output', 'o2Saturation'
]

def classify_risk(prediction):
    if prediction < 0.3:
        return 'LOW RISK'
    elif prediction < 0.7:
        return 'MEDIUM RISK'
    else:
        return 'HIGH RISK'

def get_base64_image(image_path):
    with open(image_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

def main():
    st.set_page_config(layout="wide")

    # Set the title of the web app with lighter red color
    st.markdown(
        "<h1 style='text-align: center; color: #ff6666;'>❤️ Heart Attack Risk Prediction ❤️</h1>",
        unsafe_allow_html=True
    )
    st.markdown(
        "<h2 style='text-align: center; color: #ff6666; padding: 10px; border-radius: 10px;'>Enter the patient's details to predict the risk of a heart attack:</h2>",
        unsafe_allow_html=True
    )

    # Convert image to base64 and use as background
    bg_image_base64 = get_base64_image('assets/bgimg.png')

    # Apply background image and style
    st.markdown(
        f"""
        <style>
        .stApp {{
            background-image: url(data:image/png;base64,{bg_image_base64});
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            color: #333333;
            font-family: 'Arial', sans-serif;
        }}
        .stButton>button {{
            background-color: #800000;
            color: #FFFFFF;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s;
        }}
        .stButton>button:hover {{
            background-color: #A52A2A;
        }}
        .stSlider>div {{
            color: #FFFFFF;
        }}
        .stSlider>div>div>div>input {{
            background: linear-gradient(90deg, #800000, #A52A2A);
            color: #FFFFFF;
            border-radius: 5px;
        }}
        .stTextInput>div>input {{
            background-color: #FFFFFF;
            color: #333333;
            border: 1px solid #800000;
            border-radius: 5px;
            padding: 10px;
        }}
        .stSelectbox>div>div>div>select {{
            background-color: #FFFFFF;
            color: #333333;
            border: 1px solid #800000;
            border-radius: 5px;
            padding: 10px;
        }}
        .stSubheader, .stMarkdown {{
            color: #333333;
            background-color: transparent;
            padding: 10px;
            border-radius: 10px;
        }}
        </style>
        """,
        unsafe_allow_html=True
    )

    # Create a two-column layout
    col1, col2 = st.columns([2, 1])

    with col1:
        st.subheader('Patient Details')

        # Add input fields for features
        age = st.number_input('Age', 0, 120, 50, help="Age of the person.")
        sex = st.selectbox('Gender', [0, 1], help="Gender of the person: 0 = Female, 1 = Male.")
        cp = st.selectbox('Chest Pain Type', [0, 1, 2, 3], help="Chest pain type.")
        trtbps = st.number_input('Resting Blood Pressure (mm Hg)', 0, 200, 120, help="Resting blood pressure (in mm Hg).")
        chol = st.number_input('Cholesterol (mg/dl)', 0, 600, 200, help="Cholesterol in mg/dl fetched via BMI sensor.")
        fbs = st.selectbox('Fasting Blood Sugar > 120 mg/dl', [0, 1], help="(Fasting blood sugar > 120 mg/dl): 1 = true; 0 = false.")
        restecg = st.selectbox('Resting Electrocardiographic Results', [0, 1, 2], help="Resting electrocardiographic results.")
        thalachh = st.number_input('Maximum Heart Rate Achieved', 0, 250, 150, help="Maximum heart rate achieved.")
        exng = st.selectbox('Exercise Induced Angina', [0, 1], help="Exercise induced angina: 1 = yes; 0 = no.")
        oldpeak = st.number_input('Previous Peak', 0.0, 6.0, 0.0, step=0.1, help="Previous peak.")
        slp = st.selectbox('Slope of the Peak Exercise ST Segment', [0, 1, 2], help="Slope of the peak exercise ST segment.")
        caa = st.number_input('Number of Major Vessels (0-3) Colored by Flourosopy', 0, 3, 0, help="Number of major vessels (0-3) colored by fluoroscopy.")
        thall = st.selectbox('Thalassemia', [0, 1, 2, 3], help="Thalassemia: 1 = normal; 2 = fixed defect; 3 = reversible defect.")
        o2Saturation = st.number_input('Oxygen Saturation (%)', 0, 100, 95, help="Oxygen saturation level.")

        # Prepare input data as a DataFrame
        input_data = pd.DataFrame({
            'age': [age],
            'sex': [sex],
            'cp': [cp],
            'trtbps': [trtbps],
            'chol': [chol],
            'fbs': [fbs],
            'restecg': [restecg],
            'thalachh': [thalachh],
            'exng': [exng],
            'oldpeak': [oldpeak],
            'slp': [slp],
            'caa': [caa],
            'thall': [thall],
            'output': [0],  # Dummy value
            'o2Saturation': [o2Saturation]
        })

        # Ensure columns are in the same order as during model training
        input_data = input_data[expected_columns]

    with col2:
        st.subheader('Prediction')
        if st.button('Predict'):
            with st.spinner('Predicting...'):
                # Predict the heart attack risk value
                try:
                    prediction = model.predict(input_data)[0]
                    risk = classify_risk(prediction)

                    st.markdown(f"### Predicted Risk Value: **{prediction:.2f}**")
                    st.markdown(f"### Risk Level: **{risk}**")
                except Exception as e:
                    st.error(f"An error occurred: {e}")

if __name__ == '__main__':
    main()
